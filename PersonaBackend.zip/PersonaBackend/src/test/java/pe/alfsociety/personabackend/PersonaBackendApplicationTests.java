package pe.alfsociety.personabackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonaBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
