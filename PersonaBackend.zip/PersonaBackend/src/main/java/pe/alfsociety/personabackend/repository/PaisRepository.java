package pe.alfsociety.personabackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.alfsociety.personabackend.model.Pais;

public interface PaisRepository extends JpaRepository<Pais, Long> {
}
