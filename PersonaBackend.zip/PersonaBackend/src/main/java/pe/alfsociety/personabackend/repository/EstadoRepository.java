package pe.alfsociety.personabackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.alfsociety.personabackend.model.Estado;

public interface EstadoRepository extends JpaRepository<Estado, Long> {
}
